## -----------------------------------------------------------------------------
# Vignette setup chunk
library(dplyr)
library(ggplot2)

# Load data directly from the package
tesla_stock_filtered <- TeslaInvestR::filtered_tesla_stock
roadster_value_filtered <- TeslaInvestR::filtered_roadster_value

## -----------------------------------------------------------------------------
head(tesla_stock_filtered)

## -----------------------------------------------------------------------------

# Assuming tesla_stock and roadster_value are already loaded

# Add an identifier to each dataset
tesla_stock_filtered <- tesla_stock_filtered %>%
  dplyr::mutate(type = "Tesla Stock")

roadster_value_filtered <- roadster_value_filtered %>%
  dplyr::mutate(type = "Tesla Roadster")

# Combine the two datasets into one
combined_data <- bind_rows(
  tesla_stock_filtered %>% dplyr::select(Date, investment_value, type),
  roadster_value_filtered %>% dplyr::rename(Date = date) %>% dplyr::select(Date, investment_value, type)
)

# Plot with facets
ggplot2::ggplot(combined_data, aes(x = Date, y = investment_value, color = type)) +
  geom_line() +
  labs(title = "Comparison of Tesla Stock and Roadster Depreciation",
       x = "Date", y = "Value") +
  facet_wrap(~type, scales = "free_y") +  # Facet by the type (Tesla Stock and Tesla Roadster)
  theme_minimal()


